//
//  allleaveViewController.swift
//  hrApplication
//
//  Created by SAIL on 03/10/23.
//

import UIKit
import SideMenu

class allleaveViewController: UIViewController {
    
    @IBOutlet weak var homebt: UIImageView!
    @IBOutlet weak var slable: UILabel!
    @IBOutlet weak var pcount: UILabel!
    @IBOutlet weak var rcount: UILabel!
    @IBOutlet weak var holidayView: UIView!
    @IBOutlet weak var acount: UILabel!
    @IBOutlet weak var applyView: UIView!
    @IBOutlet weak var lcount: UILabel!
    @IBOutlet weak var segmentControll: UISegmentedControl!
    
    @IBOutlet weak var leaveHistoryTable: UITableView! {
        didSet {
            leaveHistoryTable.delegate = self
            leaveHistoryTable.dataSource = self
        }
    }
    
    var countvalue: AttendanceCountModel!
    var balance: LeaveBalanceModel!
    var leavehistory: leavehistoryModel!
    var menu: SideMenuNavigationController?
    
    let userId = UserDefaultsManager.shared.getUserId() ?? ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        menu = SideMenuNavigationController(rootViewController: MenuViewController())
               menu?.leftSide = false
               
               SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        homebt.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }

        self.holidayView.isHidden = true
        self.applyView.isHidden = true
    }
   
    override func viewWillAppear(_ animated: Bool) {
        leaveHistoryAPI()
        getattendancecountAPI()
        leavebalanceAPI()
    }
    
    func leaveHistoryAPI() {
        APIHandler().getAPIValues(type: leavehistoryModel.self, apiUrl: "\(ServiceAPI.leavehistoryURL)bioid=\(userId)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.leavehistory = data
                print(self.leavehistory.data ?? "")
                print(self.leavehistory.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.leaveHistoryTable.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    func getattendancecountAPI() {
        APIHandler().getAPIValues(type: AttendanceCountModel.self, apiUrl: "\(ServiceAPI.attendancecountURL)bioid=\(userId)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.countvalue = data
                print(self.countvalue.data ?? "")
                print(self.countvalue.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.pcount.text = self.countvalue.data?.first?.presentCount
                    self.lcount.text = self.countvalue.data?.first?.lateCount
                    self.acount.text = self.countvalue.data?.first?.absentCount
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    func leavebalanceAPI() {
        APIHandler().getAPIValues(type: LeaveBalanceModel.self, apiUrl: "\(ServiceAPI.leavebalanceURL)bioid=\(userId)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.balance = data
                print(self.balance.data ?? "")
                print(self.balance.data.count ?? 0)
                DispatchQueue.main.async {
                    self.rcount.text = "\(self.balance.data.first?.total ?? 0)"
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
}

extension allleaveViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.leavehistory?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "leavehistoryTVC", for: indexPath) as! leavehistoryTVC
        
        if let leavehistory = self.leavehistory?.data?[indexPath.row] {
            cell.leaveDate.text = "\(leavehistory.startdate ?? "")"
            cell.leaveTitle.text = "\(leavehistory.title ?? "")"
            cell.leaveType.text = "\(leavehistory.leavetype ?? "")"
           
            
            
            
        } else {
            cell.leaveDate.text = "Nil"
            cell.leaveTitle.text = "Nil"
            cell.leaveType.text = "Nil"
            
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    @IBAction func segmentControlAction(_ sender: Any) {
        switch segmentControll.selectedSegmentIndex {
        case 0:
            self.leaveHistoryTable.isHidden = false
            self.holidayView.isHidden = true
            self.applyView.isHidden = true
        case 1:
            self.leaveHistoryTable.isHidden = true
            self.holidayView.isHidden = false
            self.applyView.isHidden = true
        case 2:
            self.leaveHistoryTable.isHidden = true
            self.holidayView.isHidden = true
            self.applyView.isHidden = false
        default:
            break
        }
    }
    


}
