//
//  viewsalaryViewController.swift
//  hrApplication
//
//  Created by SAIL on 03/10/23.
//

import UIKit
import SideMenu


class viewsalaryViewController: UIViewController {

    @IBOutlet weak var home: UIImageView!
    @IBOutlet weak var slable: UILabel!
    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var viewsalarytable: UITableView!{
        
        didSet {
            viewsalarytable.delegate = self
            viewsalarytable.dataSource = self
        }
    }
    
    var salary: salaryModel!
    var menu: SideMenuNavigationController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        menu = SideMenuNavigationController(rootViewController: MenuListViewController())
        menu?.leftSide = false
        
        SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
       home.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }
        
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getsalaryAPI()
    }
    
    func getsalaryAPI() {
        APIHandler().getAPIValues(type: salaryModel.self, apiUrl: ServiceAPI.viewSalaryUrl, method: "GET") { result in
            switch result {
            case .success(let data):
                self.salary = data
                print(self.salary.salaries ?? "")
                print(self.salary.salaries?.count ?? 0)
                DispatchQueue.main.async {
                    self.viewsalarytable.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}

extension viewsalaryViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.salary?.salaries?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "viewsalaryTableViewCell", for: indexPath) as! viewsalaryTableViewCell
        
        if let salaryq = self.salary?.salaries?[indexPath.row] {
            cell.bioid.text = "\(salaryq.bioid ?? "")"
            cell.basicsalary.text = "\(salaryq.basicsalary ?? "")"
            cell.date.text = "\(salaryq.date ?? "")"
            cell.allowance.text = "\(salaryq.allowance ?? "")"
            cell.total.text = "\(salaryq.total ?? "")"
     
            
            
        } else {
            cell.bioid.text = "Nil"
            cell.basicsalary.text = "Nil"
            cell.date.text = "Nil"
            cell.allowance.text = "Nil"
            cell.total.text = "Nil"

        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
}
