//
//  holidayViewController.swift
//  hrApplication
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class holidayViewController: UIViewController {

    @IBOutlet weak var holidaytable: UITableView!{
        didSet {
            holidaytable.delegate = self
            holidaytable.dataSource = self
        }
    }
    
    var holiday: HolidayModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        getHolidayAPI()
    }
    
    func getHolidayAPI() {
        APIHandler().getAPIValues(type: HolidayModel.self, apiUrl: ServiceAPI.viewHolidayURL, method: "GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.holiday = data
                print(self.holiday ?? "")
//                print(self.holiday.holidaysData?.count ?? 0)
                DispatchQueue.main.async {
                    self.holidaytable.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}

extension holidayViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.holiday?.data.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "holidayTableViewCell", for: indexPath) as! holidayTableViewCell
        if holiday != nil {
            if let holidays = self.holiday?.data[indexPath.row] {
                cell.Sno.text = "\(holidays.sno ?? "")"
            cell.HolidayName.text = "\(holidays.holidayName ?? "")"
            cell.Date.text = "\(holidays.date ?? "")"
            cell.Day.text = "\(holidays.day ?? "")"




        } else {
            cell.Sno.text = "Nil"
            cell.HolidayName.text = "Nil"
            cell.Date.text = "Nil"
            cell.Day.text = "Nil"

        }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
}
