//
//  setupViewController.swift
//  hrApplication
//
//  Created by SAIL on 06/10/23.
//

import UIKit
import SideMenu

class setupViewController: UIViewController {

    @IBOutlet weak var home: UIImageView!
    
    var menu: SideMenuNavigationController?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        menu = SideMenuNavigationController(rootViewController: MenuListViewController())
        menu?.leftSide = false
        
        SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
       home.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }

        // Do any additional setup after loading the view.
    }
    
    @IBAction func bt1(_ sender: Any) {
        AlertManager.showAlert(title: "Update Info", message: "This Option Will Be Unlocked in Next update ", viewController: self, completionHandler: nil)
    }
    
    @IBAction func bt2(_ sender: Any) {
        AlertManager.showAlert(title: "Update Info", message: "This Option Will Be Unlocked in Next update ", viewController: self, completionHandler: nil)
    }
    @IBAction func bt3(_ sender: Any) {
        AlertManager.showAlert(title: "Update Info", message: "This Option Will Be Unlocked in Next update ", viewController: self, completionHandler: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


//AlertManager.showAlert(title: "Update Info", message: "This Option Will Be Unlocked in Next update ", viewController: self, completionHandler: nil)
