//
//  profilesViewController.swift
//  hrApplication
//
//  Created by SAIL on 27/09/23.
//

import UIKit
import SideMenu

class profilesViewController: UIViewController {

    @IBOutlet weak var slable: UILabel!
    @IBOutlet weak var home: UIImageView!
    var menu: SideMenuNavigationController?
    override func viewDidLoad() {
        super.viewDidLoad()
        menu = SideMenuNavigationController(rootViewController: MenuListViewController())
        menu?.leftSide = false
        
        SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        home.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }
    }
    
    @IBAction func addprofile(_ sender: Any) {
        let addprofileVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "addprofileViewController") as! addprofileViewController
        self.navigationController?.pushViewController(addprofileVC, animated: true)
        
    }
    @IBAction func viewprofile(_ sender: Any) {
        let viewVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "viewprofileViewController") as! viewprofileViewController
        self.navigationController?.pushViewController(viewVC, animated: true)
    }
    @IBAction func deleteprofile(_ sender: Any) {
        let deleteVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "deleteprofileViewController") as! deleteprofileViewController
        self.navigationController?.pushViewController(deleteVC, animated: true)
    }
    
    @IBAction func editprofile(_ sender: Any) {
        let editVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "editprofilelistViewController") as! editprofilelistViewController
        self.navigationController?.pushViewController(editVC, animated: true)
    }
    

}
