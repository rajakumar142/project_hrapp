//
//  acceptPermissionTableViewCell.swift
//  hrApplication
//
//  Created by SAIL on 26/09/23.
//

import UIKit

class acceptPermissionTableViewCell: UITableViewCell {

    @IBOutlet weak var bioid: UILabel!
    @IBOutlet weak var phone: UILabel!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var viewMore: UIButton!
    @IBOutlet weak var gtitle: UILabel!
    @IBOutlet weak var date: NSLayoutConstraint!
    @IBOutlet weak var gdate: UILabel!
    @IBOutlet weak var deletebt: UIButton!
    @IBOutlet weak var accetpbt: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        accetpbt.tintColor = UIColor(red: 0.18823529411764706, green: 0.7450980392156863, blue: 0.7137254901960784, alpha: 1.0)
        deletebt.tintColor = UIColor(red: 1, green: 0.4980392156862745, blue: 0.4549019607843137, alpha: 1.0)
        // Initialization code
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
   
    @IBAction func reject(_ sender: Any) {
    }
    @IBAction func accept(_ sender: Any) {
    }
    
    

}
