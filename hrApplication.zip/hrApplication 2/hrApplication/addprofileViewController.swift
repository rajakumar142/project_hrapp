//
//  addprofileViewController.swift
//  hrApplication
//
//  Created by SAIL on 27/09/23.
//

import UIKit
import SideMenu
import Foundation
import UIKit

struct MultipleUrlToDataConverModel: Codable,Equatable{
    let code:String?
    let data: Data
    init(code:String, data:Data) {
        self.code = code
        self.data = data
    }
    static func == (lhs: MultipleUrlToDataConverModel, rhs: MultipleUrlToDataConverModel) -> Bool {
        return lhs.code == rhs.code
    }
}



class addprofileViewController: UIViewController ,UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    
    @IBOutlet weak var uploadimage: UIImageView!
    @IBOutlet weak var ddbt2: UIImageView!
    @IBOutlet weak var ddbt: UIImageView!
    @IBOutlet weak var ddbtd: UIImageView!
    @IBOutlet weak var slable: UILabel!
    @IBOutlet weak var date1: UIImageView!
    @IBOutlet weak var home: UIImageView!
    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var expddbt: UIImageView!
    @IBOutlet weak var desiganationddbt: UIImageView!
    @IBOutlet weak var deptddbt: UIImageView!
    @IBOutlet weak var usertypeddbt: UIImageView!
    @IBOutlet weak var bioid: BorderedTextField!
    @IBOutlet weak var name: BorderedTextField!
    @IBOutlet weak var DOB: BorderedTextField!
    @IBOutlet weak var email: BorderedTextField!
    @IBOutlet weak var phone: BorderedTextField!
    @IBOutlet weak var password: BorderedTextField!
    @IBOutlet weak var shift: BorderedTextField!
    @IBOutlet weak var experience: BorderedTextField!
    @IBOutlet weak var usertype: BorderedTextField!
    @IBOutlet weak var desiganation: BorderedTextField!
    @IBOutlet weak var dept: BorderedTextField!
    @IBOutlet weak var jobtype: BorderedTextField!
    
    var datePicker = UIDatePicker()

    var picker = UIPickerView()
    var jobTypePicker = [String]()
    var shiftPicker = [String]()
    
    var deptmentlist: managedept!
    var deptpicker : [String] = []
    
    var usertypePicker = [String]()
    var experiencePicker = [String]()
    var desiganationPicker = [String]()
    var selectedImage = UIImage()
    var uploadImage = String()
    var menu: SideMenuNavigationController?
    var getCurrentDate = Date()
    
    var convertImage:Data?
    
    var uploadingFileDataArray: [MultipleUrlToDataConverModel] = [MultipleUrlToDataConverModel]()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        dept.isUserInteractionEnabled = false
        DOB.isUserInteractionEnabled = false
        shift.isUserInteractionEnabled = false
        experience.isUserInteractionEnabled = false
        usertype.isUserInteractionEnabled = false
        desiganation.isUserInteractionEnabled = false
        jobtype.isUserInteractionEnabled = false
        
        
        menu = SideMenuNavigationController(rootViewController: MenuListViewController())
        menu?.leftSide = false
        
        SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
       home.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }
        uploadimage.addAction(for: .tap) {
            let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
                    
//                    let cameraAct: UIAlertAction = UIAlertAction(title: "Camera", style: .default) { action -> Void in
////                        self.opencamera()
//                    }
                    
                    let galleryAct: UIAlertAction = UIAlertAction(title: "Photo Library", style: .default) { action -> Void in
                        self.openGallery()
                        
                    }
                    
                    let cancelAct: UIAlertAction = UIAlertAction(title: "Cancel", style: .cancel)
                    //For creating Action
                    
//                    alert.addAction(cameraAct)
                    alert.addAction(galleryAct)
                    alert.addAction(cancelAct)
                    
                    //To present the Alert
                    
            self.present(alert, animated: true)
        }
        
        self.jobTypePicker = ["Permanent", "Part time", "Intern", "Other"]
        self.shiftPicker = ["Shift 1", "Shift 2", "Shift 3", "Other"]
        self.desiganationPicker=["Team lead", "Project manager", "Project lead", "Developer", "Designer", "Other"]
        self.experiencePicker=["0 to 1 year", "2 to 5 years", "6 to 8 years","More than 8 years"]
        
        self.usertypePicker=["Admin","User","Reviewer"]
//        self.datePicker =
        
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
        
        
        date1.addAction(for: .tap) {
            self.datePicker = UIDatePicker(frame: CGRect(x: 40, y: 290, width: 50, height: 150))
            self.datePicker.datePickerMode = .date
            self.datePicker.preferredDatePickerStyle = .inline
            self.datePicker.backgroundColor = .white
            self.datePicker.addTarget(self, action: #selector(self.dateSelected), for: .allEvents)
            self.view.addSubview(self.datePicker)
        }
        
        ddbt.addAction(for: .tap) {
            self.variantListAPI(names: self.jobTypePicker, textFiled: self.jobtype)
            
        }
        ddbt2.addAction(for: .tap) {
            self.variantListAPI(names: self.shiftPicker, textFiled: self.shift)
        }
        expddbt.addAction(for: .tap) {
            self.variantListAPI(names: self.experiencePicker, textFiled: self.experience)
        }
        desiganationddbt.addAction(for: .tap) {
            self.variantListAPI(names: self.desiganationPicker, textFiled: self.desiganation)
        }
        usertypeddbt.addAction(for: .tap) {
            self.variantListAPI(names: self.usertypePicker, textFiled: self.usertype)
        }
        deptddbt.addAction(for: .tap) {
            self.variantListAPI(names: self.deptpicker, textFiled: self.dept)
        }
//
        
//            self.picker = UIPickerView(frame: CGRect(x: 40, y: 350, width: 300, height: 200))
//            self.picker.delegate = self
//            self.picker.dataSource = self
            //        self.view.addSubview(self.picker)
            
        
//
//            let toolBar = UIToolbar()
//            toolBar.barStyle = UIBarStyle.default
//            toolBar.isTranslucent = true
//            toolBar.tintColor = UIColor(red: 76/255, green: 217/255, blue: 100/255, alpha: 1)
//            toolBar.sizeToFit()
//
//            let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.done, target: self, action: #selector(self.donePicker))
//            let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
//            let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.donePicker))
//
//            toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
//            toolBar.isUserInteractionEnabled = true
//
//            self.jobtype.inputView = self.picker
//            self.jobtype.inputAccessoryView = toolBar
//            self.shift.inputView = self.picker
//            self.shift.inputAccessoryView = toolBar
        
        
        
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        getDeptAPI()
    }
    func getDeptAPI() {
        APIHandler().getAPIValues(type: managedept.self, apiUrl: ServiceAPI.viewDeptUrl, method: "GET") { result in
            switch result {
            case .success(let data):
                self.deptmentlist = data
                if let department = self.deptmentlist.departments {
                    self.deptpicker = department.map { $0.department ?? " " }
                    DispatchQueue.main.async {
                        self.picker.reloadAllComponents()
                    }
                }
              
//                deptpicker = deptmentlist.departments?.description
                
                
                print(self.deptmentlist.departments ?? "name")
                print(self.deptmentlist.departments?.count ?? 0)
                
            case .failure(let error):
                print(error)
            }
        }
    }
//    func updateDeptPicker() {
//        self.picker.reloadAllComponents()
//
//    }
//    func opencamera() {
//            let vc = UIImagePickerController()
//            vc.sourceType = .camera
//            vc.delegate = self
//            vc.allowsEditing = true
//            present(vc, animated: true)
//        }
    
    func openGallery() {
            let vc = UIImagePickerController()
            vc.sourceType = .photoLibrary
            vc.delegate = self
            vc.allowsEditing = true
            present(vc, animated: true)
            
        }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.originalImage] as? UIImage {
            if let imageURL = info[.imageURL] as? URL {
                let imageName = imageURL.lastPathComponent
                
                // Save image to a local path
                if let imageData = image.jpegData(compressionQuality: 1) {
                    let documentDirectory = FileManager.default.temporaryDirectory
                    let localPath = documentDirectory.appendingPathComponent(imageName)
                    convertImage = imageData
                    do {
                        try imageData.write(to: localPath)
                        
                      
                        
                        uploadimage.image = image
                        self.selectedImage = image
                    } catch {
                        print("Error saving image: \(error)")
                    }
                }
            }
        }
        
        // Dismiss the UIImagePicker after selection
        picker.dismiss(animated: true)
    }
   
    
    
    
    
    func uploadImage(image: UIImage, completion: @escaping (String?) -> Void) {
        let urlString = "http://192.168.76.171/hrapp/Apis/addprofile.php"
        let boundary = "Boundary-\(UUID().uuidString)"
        let mimeType = "image/png" // Set the image mime type accordingly

        guard let url = URL(string: urlString) else {
            completion("Invalid URL")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        let body = NSMutableData()

        // Add image data to the form data
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"image\"; filename=\"image.png\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: \(mimeType)\r\n\r\n".data(using: .utf8)!)

        if let imageData = image.pngData() {
            body.append(imageData)
        }

        body.append("\r\n".data(using: .utf8)!)
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)

        request.httpBody = body as Data

        URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                completion(error?.localizedDescription)
                return
            }

            if let responseString = String(data: data, encoding: .utf8) {
                completion(responseString)
            } else {
                completion(nil)
            }
        }.resume()
    }



            
  
    
    
    


   
    

       
    
    
   

    @objc func donePicker() {
        jobtype.resignFirstResponder()
    }
    
    @objc func dateSelected(){
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateString = dateFormatter.string(from: datePicker.date)
        print(dateString)
        DOB.text = dateString
        self.datePicker.isHidden = true
    }
    
    
    @IBAction func addprofile(_ sender: Any) {
        uploadImage(image: selectedImage, completion: { result in
            print(result ?? "")
            self.addProfileAPI()
        })
    }
    
    
    
  
    
    func variantListAPI(names : [String], textFiled : UITextField){
                let actionSheetAlertController: UIAlertController = UIAlertController(title: nil, message: "Select", preferredStyle: .actionSheet)
                let i = names.count - 1
                if names.count != 0 {
                    for  n in 0...i {
                        let action = UIAlertAction(title: names[n], style: .default) { (action) in
                            print("Title: \(names[n])")
                            print("ID: \(names[n])")
                            textFiled.text = names[n]
                        }
                        action.setValue(CATextLayerAlignmentMode.left, forKey: "titleTextAlignment")
                        action.setValue(UIColor.black, forKey: "titleTextColor")
                        actionSheetAlertController.addAction(action)
                    }
                }
                else {
                    print("No measureArrStr Data")
                }
                let cancelActionButton = UIAlertAction(title: "Cancel", style: .destructive, handler: nil)
                actionSheetAlertController.addAction(cancelActionButton)
                self.present(actionSheetAlertController, animated: true, completion: nil)
            }
    
    func addProfileAPI() {
        let formData: [String: Any] = [
            "bioid": bioid.text ?? "",
            "name": name.text ?? "",
            "email": email.text ?? "",
            "DOB": DOB.text ?? "",
            "phonenumber": phone.text ?? "",
            "jobtype": jobtype.text ?? "",
            "designation": desiganation.text ?? "",
            "department": dept.text ?? "",
            "experience": experience.text ?? "",
            "password": password.text ?? "",
            "shift": shift.text ?? "",
            "profilepic": "\(convertImage)",
            "usertype": usertype.text ?? ""

        ]

       // convertImagess()
        APIHandler().postAPIValues(type: addprofileModel.self, apiUrl: ServiceAPI.addprofileURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Message: \(response.message)")

                DispatchQueue.main.async {

                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }


    }
  
    
 
    
  
}


extension Date {
    func getCurrentDate(format: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        return dateFormatter.string(from: self)
    }
}



extension UIImage {
    
    func imageToBase64() -> String? {
        
        return self.jpegData(compressionQuality: 0.5)?.base64EncodedString()
    }
}
