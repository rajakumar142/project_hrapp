//
//  viewsalaryuViewController.swift
//  hrApplication
//
//  Created by SAIL on 05/10/23.
//

import UIKit
import SideMenu

class viewsalaryuViewController: UIViewController {
    
    @IBOutlet weak var home: UIImageView!
    @IBOutlet weak var slable: UILabel!
    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var viewsalaryutable: UITableView! {
        didSet {
            viewsalaryutable.delegate = self
            viewsalaryutable.dataSource = self
        }
    }
    
    var userId = UserDefaultsManager.shared.getUserId() ?? ""
    
    var usalary: usersalaryModel!
    var menu: SideMenuNavigationController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        menu = SideMenuNavigationController(rootViewController: MenuViewController())
               menu?.leftSide = false
               
               SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        home.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }
        
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getusalaryAPI()
    }
    
    func getusalaryAPI() {
        APIHandler().getAPIValues(type: usersalaryModel.self, apiUrl: "\(ServiceAPI.salaryURL)bioid=\(userId)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.usalary = data
                print(self.usalary.data ?? "")
                print(self.usalary.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.viewsalaryutable.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
}





extension viewsalaryuViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.usalary?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "viewsalaryuTableViewCell", for: indexPath) as! viewsalaryuTableViewCell
        
        if let salaryq = self.usalary?.data?[indexPath.row] {
            cell.bioid.text = UserDefaultsManager.shared.getUserId()
            cell.basicsalary.text = "\(salaryq.basicsalary ?? "")"
            cell.date.text = "\(salaryq.date ?? "")"
            cell.allowance.text = "\(salaryq.allowance ?? "")"
            cell.total.text = "\(salaryq.total ?? "")"
            
            
            
        } else {
            cell.bioid.text = "Nil"
            cell.basicsalary.text = "Nil"
            cell.date.text = "Nil"
            cell.allowance.text = "Nil"
            cell.total.text = "Nil"
            
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
}
