//
//  viewsalaryTableViewCell.swift
//  hrApplication
//
//  Created by SAIL L1 on 11/10/23.
//

import UIKit

class viewsalaryTableViewCell: UITableViewCell {

 
    @IBOutlet weak var allowance: UILabel!
    @IBOutlet weak var total: UILabel!
    @IBOutlet weak var basicsalary: UILabel!
    @IBOutlet weak var lable3: UILabel!
    @IBOutlet weak var bioid: UILabel!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var lable1: UILabel!
    @IBOutlet weak var lable2: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
