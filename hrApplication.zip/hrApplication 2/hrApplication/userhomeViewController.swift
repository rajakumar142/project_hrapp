//
//  userhomeViewController.swift
//  hrApplication
//
//  Created by Thiran Raj on 03/10/23.
//

import UIKit
import SideMenu
	
class userhomeViewController: UIViewController {


    @IBOutlet weak var lcount: UILabel!
    @IBOutlet weak var acount: UILabel!
    @IBOutlet weak var pcount: UILabel!
    @IBOutlet weak var slable: UILabel!
    @IBOutlet weak var menubar: UIImageView!
    
    var attendance: AttendanceModel!
    var countvalue: AttendanceCountModel!
    var menu: SideMenuNavigationController?
    
    var dataPoints: [Double?] = []
    var colors: [UIColor] = []
    
    let userId = UserDefaultsManager.shared.getUserId() ?? ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        menu = SideMenuNavigationController(rootViewController: MenuViewController())
        menu?.leftSide = false
        
        SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        menubar.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        chartAPI()
        self.navigationController?.navigationBar.isHidden = true
        getattendancecountAPI()
    }
    
    func getattendancecountAPI() {
        APIHandler().getAPIValues(type: AttendanceCountModel.self, apiUrl: "\(ServiceAPI.attendancecountURL)bioid=\(userId)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.countvalue = data
                print(self.countvalue.data ?? "")
                print(self.countvalue.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.pcount.text = self.countvalue.data?.first?.presentCount
                    self.lcount.text = self.countvalue.data?.first?.lateCount
                    self.acount.text = self.countvalue.data?.first?.absentCount
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func chartAPI() {
        APIHandler().getAPIValues(type: AttendanceModel.self, apiUrl: "\(ServiceAPI.attendanceURL)bioid=\(userId)", method: "GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.attendance = data
                DispatchQueue.main.async {
                    let ringPieChartSize: CGFloat = 120
                    let ringPieChartX = (self.view.bounds.width - ringPieChartSize) / 2
                    let ringPieChartY = (self.view.bounds.height - ringPieChartSize) / 3.5
                    let ringPieChartView = UIView(frame: CGRect(x: ringPieChartX, y: ringPieChartY, width: ringPieChartSize, height: ringPieChartSize))
                    self.view.addSubview(ringPieChartView)
                    
                    // Calculate the data points and colors
                    if let absentPercentage = self.attendance.data?.first?.absentPercentage,
                       let latePercentage = self.attendance.data?.first?.latePercentage,
                       let presentPercentage = self.attendance.data?.first?.presentPercentage {
                        self.dataPoints = [absentPercentage, latePercentage, presentPercentage]
                    } else {
                        self.dataPoints = [0, 0, 0]
                    }
                    
                    self.colors = [.red, .yellow, .green]
                    
                    let total = self.dataPoints.reduce(0.0) { (result, nextValue) -> Double in
                        if let value = nextValue {
                            return result + value
                        } else {
                            return result
                        }
                    }

                    var startAngle: CGFloat = -.pi / 2
                    
                    for (index, value) in self.dataPoints.enumerated() {
                        let angle = 2 * .pi * CGFloat(value ?? 0) / CGFloat(total)
                        
                        let outerPath = UIBezierPath(arcCenter: CGPoint(x: ringPieChartView.bounds.midX, y: ringPieChartView.bounds.midY),
                                                     radius: ringPieChartSize / 2,
                                                     startAngle: startAngle,
                                                     endAngle: startAngle + angle,
                                                     clockwise: true)
                        
                        let sectorLayer = CAShapeLayer()
                        sectorLayer.path = outerPath.cgPath
                        sectorLayer.strokeColor = self.colors[index].cgColor
                        sectorLayer.fillColor = UIColor.clear.cgColor
                        sectorLayer.lineWidth = ringPieChartSize
                        sectorLayer.strokeStart = 0
                        sectorLayer.strokeEnd = 1
                        
                        ringPieChartView.layer.addSublayer(sectorLayer)
                        
                        startAngle += angle
                    }
                    
                    let centerCircle = UIView(frame: CGRect(x: ringPieChartView.bounds.midX - ringPieChartSize / 2, y: ringPieChartView.bounds.midY - ringPieChartSize / 2, width: 120, height: 120))
                    centerCircle.backgroundColor = .white
                    centerCircle.layer.cornerRadius = 60
                    ringPieChartView.addSubview(centerCircle)
                }
            case .failure(let error):
                print(error)
            }
        }
    }

    

    @IBAction func actionbt(_ sender: Any) {
        let actionVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "actionViewController") as! actionViewController
        self.navigationController?.pushViewController(actionVC, animated: true)
    }
    @IBAction func profile(_ sender: Any) {
        let profileVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "viewprofile1ViewController") as! viewprofile1ViewController
        self.navigationController?.pushViewController(profileVC, animated: true)
    }

}
