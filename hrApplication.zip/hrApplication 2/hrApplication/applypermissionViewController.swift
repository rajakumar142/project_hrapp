//
//  applypermissionViewController.swift
//  hrApplication
//
//  Created by SAIL on 27/09/23.
//

import UIKit
import SideMenu

class applypermissionViewController: UIViewController {

    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var slable: UILabel!
    @IBOutlet weak var home: UIImageView!
    @IBOutlet weak var sdate: UIImageView!
    @IBOutlet weak var stime1: UIImageView!
    @IBOutlet weak var phone: BorderedTextField!
    @IBOutlet weak var etime1: UIImageView!
    @IBOutlet weak var titleb: BorderedTextField!
    @IBOutlet weak var date: BorderedTextField!
    @IBOutlet weak var starttime: BorderedTextField!
    @IBOutlet weak var endtime: BorderedTextField!
    @IBOutlet weak var reason: BorderedTextField!
    
    var bioID : String = UserDefaultsManager.shared.getUserId() ?? ""
    var menu: SideMenuNavigationController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        menu = SideMenuNavigationController(rootViewController: MenuViewController())
               menu?.leftSide = false
               
               SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        home.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }
        
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }

        // Do any additional setup after loading the view.
    }
    

    @IBAction func request(_ sender: Any) {
        applypermissionAPI()
    }
    
    func applypermissionAPI() {
        let formData: [String: String] = [

            "bioid": self.bioID,
            "title": titleb.text ?? "",
            "phonenumber": phone.text ?? "",
            "starttime": starttime.text ?? "",
            "endtime": endtime.text ?? "",
            "date": date.text ?? "",
            "reason": reason.text ?? ""
        ]
        APIHandler().postAPIValues(type: applypermissionModel.self, apiUrl: ServiceAPI.applypermissionURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Success: \(response.success)")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                    for controller in self.navigationController!.viewControllers as Array {
                        if controller.isKind(of: userhomeViewController.self) {
                            self.navigationController!.popToViewController(controller, animated: true)
                            break
                        }
                    }
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
    
}
