//
//  addsalarylistTableViewCell.swift
//  hrApplication
//
//  Created by SAIL on 15/11/23.
//

import UIKit

class addsalarylistTableViewCell: UITableViewCell {
    @IBOutlet weak var bioid: UILabel!
    
    @IBOutlet weak var addsalary: UIButton!
    @IBOutlet weak var name: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
