//
//  departmentViewController.swift
//  hrApplication
//
//  Created by SAIL on 27/09/23.
//

import UIKit
import SideMenu

class departmentViewController: UIViewController {

    @IBOutlet weak var stitle: UILabel!
    @IBOutlet weak var home: UIImageView!
    var menu: SideMenuNavigationController?
    override func viewDidLoad() {
        super.viewDidLoad()

        menu = SideMenuNavigationController(rootViewController: MenuListViewController())
        menu?.leftSide = false
        
        SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        home.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }
    }
    @IBAction func adddept(_ sender: Any) {
        let addVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "adddeptViewController") as! adddeptViewController
        self.navigationController?.pushViewController(addVC, animated: true)
    }
    
    @IBAction func managedept(_ sender: Any) {
        let manageVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "managedeptViewController") as! managedeptViewController
        self.navigationController?.pushViewController(manageVC, animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
