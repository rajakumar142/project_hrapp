//
//  permissionViewController.swift
//  hrApplication
//
//  Created by SAIL on 15/11/23.
//

import UIKit
import SideMenu

class permissionViewController: UIViewController {
    @IBOutlet weak var endtime: UILabel!
    @IBOutlet weak var reason: UILabel!
    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var starttime: UILabel!
    @IBOutlet weak var permissiontitle: UILabel!
    @IBOutlet weak var permissiontype: UILabel!
    @IBOutlet weak var phone: UILabel!
    @IBOutlet weak var home: UIImageView!
    @IBOutlet weak var bioid: UILabel!
    
    var approve: approvepermissionModel!
    var menu: SideMenuNavigationController?
    
    var bioIdStr = String()
    var titleStr = String()
    var dateStr = String()
    var stimeStr = String()
    var etimeStr = String()
    var phoneStr = String()
    var reasonStr = String()
    
    override func viewDidLoad() {
        
        bioid.text = bioIdStr
        permissiontitle.text = titleStr
        permissiontype.text = dateStr
        starttime.text = stimeStr
        endtime.text = etimeStr
        phone.text = phoneStr
        reason.text = reasonStr
        
        super.viewDidLoad()
        
        menu = SideMenuNavigationController(rootViewController: MenuViewController())
               menu?.leftSide = false
               
               SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        home.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }
        
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
    }

        
    }
    

 

}
