//
//  addsalaryViewController.swift
//  hrApplication
//
//  Created by SAIL on 03/10/23.
//

import UIKit
import SideMenu

class addsalaryViewController: UIViewController {

    @IBOutlet weak var date1: UIImageView!
    @IBOutlet weak var home: UIImageView!
    @IBOutlet weak var slable: NSLayoutConstraint!
    @IBOutlet weak var date: BorderedTextField!
    @IBOutlet weak var BACK: UIImageView!
    @IBOutlet weak var basicsalary: BorderedTextField!
    @IBOutlet weak var total: BorderedTextField!
    @IBOutlet weak var allowance: BorderedTextField!
    
    var menu: SideMenuNavigationController?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        menu = SideMenuNavigationController(rootViewController: MenuListViewController())
        menu?.leftSide = false
        
        SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
       home.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }
        
        BACK.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)

        // Do any additional setup after loading the view.
    }
    }

    @IBAction func addSalary(_ sender: Any) {
        addSalaryAPI()
        
    }
    func addSalaryAPI() {
        let formData: [String: String] = [

//            "bioid": bioid.text ?? "",
            "basicsalary": basicsalary.text ?? "",
            "allowance": allowance.text ?? "",
            "date": date.text ?? "",
            "total": total.text ?? ""
        ]
        APIHandler().postAPIValues(type: addsalaryModel.self, apiUrl: ServiceAPI.addsalaryURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Success: \(response.success)")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                    for controller in self.navigationController!.viewControllers as Array {
                        if controller.isKind(of: adminhomeViewController.self) {
                            self.navigationController!.popToViewController(controller, animated: true)
                            break
                        }
                    }
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
    
}

