//
//  viewprofile1ViewController.swift
//  hrApplication
//
//  Created by SAIL on 03/10/23.
//

import UIKit
import SideMenu

class viewprofile1ViewController: UIViewController {
    @IBOutlet weak var bioid: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var home: UIImageView!
    @IBOutlet weak var designation: UILabel!
    @IBOutlet weak var mail1: UILabel!
    
    @IBOutlet weak var bioid1: UILabel!
    @IBOutlet weak var name1: UILabel!
    @IBOutlet weak var phone1: UILabel!
    @IBOutlet weak var jobtype1: UILabel!
    @IBOutlet weak var designation1: UILabel!
    @IBOutlet weak var department1: UILabel!
    @IBOutlet weak var experience1: UILabel!
    @IBOutlet weak var experience: UILabel!
    
    @IBOutlet weak var dob: UILabel!
    @IBOutlet weak var dblable: UILabel!
    @IBOutlet weak var department: UILabel!
    @IBOutlet weak var jobtype: UILabel!
    @IBOutlet weak var profilepic: UIImageView!
    @IBOutlet weak var phone: UILabel!
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var slable: UILabel!
    
    var profile: userprofileModel!
    var menu: SideMenuNavigationController?
    var imageurlStr = String()
    
    let userId = UserDefaultsManager.shared.getUserId() ?? ""
 
    override func viewDidLoad() {
        super.viewDidLoad()

        menu = SideMenuNavigationController(rootViewController: MenuViewController())
               menu?.leftSide = false
               
               SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        home.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getProfileAPI()
    }
    
    func getProfileAPI() {
        APIHandler().getAPIValues(type: userprofileModel.self, apiUrl: "\(ServiceAPI.profileURL)bioid=\(userId)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.profile = data
                print(self.profile.data ?? "")
                print(self.profile.data?.count ?? 0)
                DispatchQueue.main.async { [self] in
                    self.bioid1.text = UserDefaultsManager.shared.getUserId()
                    self.name1.text = self.profile.data?.first?.name
                    self.phone1.text = self.profile.data?.first?.phonenumber
                    self.jobtype1.text = self.profile.data?.first?.jobtype
                    self.experience1.text = self.profile.data?.first?.experience
                    self.mail1.text = self.profile.data?.first?.email
                    self.designation1.text = self.profile.data?.first?.designation
                    self.department1.text = self.profile.data?.first?.department
                    self.dob.text = self.profile.data?.first?.dob
                    if let profiles = self.profile?.data
                    {
                        let imageString = String(profile.data?.first?.image  ?? "http://192.168.76.171/hrapp/uploads/profile655b9adf1945ddefault.png")
                    if let imageURL = URL(string: imageString) {

                                DispatchQueue.global().async {
                                    if let imageData = try? Data(contentsOf: imageURL) {

                                        if let image = UIImage(data: imageData) {
                                            DispatchQueue.main.async {
                                                self.profilepic.image = image

                                            }
                                        }
                                    }
                                }
                            }
                }
                    else {
                        self.bioid.text = "Nil"
                        self.name.text = "Nil"
                    }
//                case failure(error):
//                print(error)
            }

         
case .failure(let error):
                print(error)
            }
    }
}
}

