//
//  viewprofileinfoViewController.swift
//  hrApplication
//
//  Created by SAIL on 15/11/23.
//

import UIKit
import SideMenu


class viewprofileinfoViewController: UIViewController {
    @IBOutlet weak var bioid: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var home: UIImageView!
    @IBOutlet weak var designation: UILabel!
    @IBOutlet weak var mail1: UILabel!
    
    @IBOutlet weak var bioid1: UILabel!
    @IBOutlet weak var name1: UILabel!
    @IBOutlet weak var phone1: UILabel!
    @IBOutlet weak var jobtype1: UILabel!
    @IBOutlet weak var designation1: UILabel!
    @IBOutlet weak var department1: UILabel!
    @IBOutlet weak var experience1: UILabel!
    @IBOutlet weak var experience: UILabel!
    
    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var dob: UILabel!
    @IBOutlet weak var dblable: UILabel!
    @IBOutlet weak var department: UILabel!
    @IBOutlet weak var jobtype: UILabel!
    @IBOutlet weak var profilepic: UIImageView!
    @IBOutlet weak var phone: UILabel!
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var slable: UILabel!
    
    var profile: userprofileModel!
    var menu: SideMenuNavigationController?
    
    var bioidStr = String()
    var nameStr = String()
    var emailStr = String()
    var dobStr = String()
    var phoneStr = String()
    var jobtypeStr = String()
    var designationStr = String()
    var departmentStr = String()
    var experienceStr = String()
    var imageurlStr = String()
    
    
    
    override func viewDidLoad() {
        
        bioid1.text = bioidStr
        name1.text = nameStr
        phone1.text = phoneStr
        jobtype1.text = jobtypeStr
        experience1.text = experienceStr
        mail1.text = emailStr
        designation1.text = designationStr
        department1.text = departmentStr
        dob.text = dobStr
        if let imageURL = URL(string: imageurlStr) {

                    DispatchQueue.global().async {
                        if let imageData = try? Data(contentsOf: imageURL) {

                            if let image = UIImage(data: imageData) {
                                DispatchQueue.main.async {
                                    self.profilepic.image = image

                                }
                            }
                        }
                    }
                }
//        profilepic.image = UIImage(named: imageurlStr)
        
        super.viewDidLoad()
        
        menu = SideMenuNavigationController(rootViewController: MenuListViewController())
        menu?.leftSide = false
        
        SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        home.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }
            back.addAction(for: .tap) {
                self.navigationController?.popViewController(animated: true)
            }
       
    }
}
