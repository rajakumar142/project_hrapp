//
//  approveleaveTableViewCell.swift
//  hrApplication
//
//  Created by SAIL on 18/10/23.
//

import UIKit

class approveleaveTableViewCell: UITableViewCell {
    @IBOutlet weak var bioid: UILabel!
    
        @IBOutlet weak var date: UILabel!
    @IBOutlet weak var phone: UILabel!
    @IBOutlet weak var leavetitle: UILabel!
    @IBOutlet weak var viewMore: UIButton!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var dlable: UILabel!
    @IBOutlet weak var lable: UILabel!
    @IBOutlet weak var acceptBtn: UIButton!
    @IBOutlet weak var rejectBtn: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        acceptBtn.tintColor = UIColor(red: 0.18823529411764706, green: 0.7450980392156863, blue: 0.7137254901960784, alpha: 1.0)
        rejectBtn.tintColor = UIColor(red: 1, green: 0.4980392156862745, blue: 0.4549019607843137, alpha: 1.0)
        
        
        
        // Initialization code
    }
	
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func reject(_ sender: Any) {
    }
    @IBAction func accept(_ sender: Any) {
    }
    
}
