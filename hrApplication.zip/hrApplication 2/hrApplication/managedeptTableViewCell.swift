//
//  managedeptTableViewCell.swift
//  hrApplication
//
//  Created by SAIL on 12/10/23.
//

import UIKit

class managedeptTableViewCell: UITableViewCell {
    @IBOutlet weak var department: UILabel!
    
    @IBOutlet weak var deleteBT: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        deleteBT.tintColor = UIColor(red: 1, green: 0.4980392156862745, blue: 0.4549019607843137, alpha: 1.0)
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
