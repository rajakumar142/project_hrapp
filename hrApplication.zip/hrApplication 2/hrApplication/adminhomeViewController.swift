//
//  adminhomeViewController.swift
//  hrApplication
//
//  Created by SAIL on 27/09/23.
//

import UIKit
import SideMenu

class adminhomeViewController: UIViewController {

    @IBOutlet weak var slable: UILabel!
    
    @IBOutlet weak var menuImage: UIImageView!
    
    var menu: SideMenuNavigationController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        menu = SideMenuNavigationController(rootViewController: MenuListViewController())
        menu?.leftSide = false
        
        SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        menuImage.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    
    
    @IBAction func profile(_ sender: Any) {
        let profilesVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "profilesViewController") as! profilesViewController
        self.navigationController?.pushViewController(profilesVC, animated: true)
    }
    @IBAction func department(_ sender: Any) {
        let deptVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "departmentViewController") as! departmentViewController
        self.navigationController?.pushViewController(deptVC, animated: true)
    }
    @IBAction func salary(_ sender: Any) {
        let salaryVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "salaryViewController") as! salaryViewController
        self.navigationController?.pushViewController(salaryVC, animated: true)
    }
    
}
