//
//  applyleaveViewController.swift
//  hrApplication
//
//  Created by SAIL on 20/09/23.
//

import UIKit
import SideMenu

class applyleaveViewController: UIViewController {

    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var applylable: UILabel!
    @IBOutlet weak var home: UIImageView!
    @IBOutlet weak var titleb: BorderedTextField!
    @IBOutlet weak var phonenumber: BorderedTextField!
    
    @IBOutlet weak var reason: BorderedTextField!
    @IBOutlet weak var enddate: BorderedTextField!
    @IBOutlet weak var startdate: BorderedTextField!
    @IBOutlet weak var leavetype: BorderedTextField!
    @IBOutlet weak var date2: UIImageView!
    @IBOutlet weak var date1: UIImageView!
    @IBOutlet weak var dropbox: UIImageView!
    
    var bioID : String = UserDefaultsManager.shared.getUserId() ?? ""
    var menu: SideMenuNavigationController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        menu = SideMenuNavigationController(rootViewController: MenuViewController())
               menu?.leftSide = false
               
               SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        home.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }
        
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }

        // Do any additional setup after loading the view.
    }
    

    @IBAction func requestbt(_ sender: Any) {
        applyleaveAPI()
    }
    func applyleaveAPI() {
        let formData: [String: String] = [

            "bioid": self.bioID,
            "title": titleb.text ?? "",
            "phonenumber": phonenumber.text ?? "",
            "startdate": startdate.text ?? "",
            "enddate": enddate.text ?? "",
            "leavetype": leavetype.text ?? "",
            "reason": reason.text ?? ""
        ]
        APIHandler().postAPIValues(type: applyleaveModel.self, apiUrl: ServiceAPI.applyleaveURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Success: \(response.success)")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                    for controller in self.navigationController!.viewControllers as Array {
                        if controller.isKind(of: userhomeViewController.self) {
                            self.navigationController!.popToViewController(controller, animated: true)
                            break
                        }
                    }
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
    
}

