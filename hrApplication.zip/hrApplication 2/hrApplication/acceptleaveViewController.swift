//
//  acceptleaveViewController.swift
//  hrApplication
//
//  Created by SAIL on 26/09/23.
//

import UIKit
import SideMenu

class acceptleaveViewController: UIViewController {

    @IBOutlet weak var approveleaveTableViewCell: UITableView!{
        didSet {
            approveleaveTableViewCell.delegate = self
            approveleaveTableViewCell.dataSource = self
        }
    }
    @IBOutlet weak var head: UILabel!
    @IBOutlet weak var home: UIImageView!
    @IBOutlet weak var back: UIImageView!
    
    var approve: approveleaveModel!
    var acptleave: acceptleave!
    var rejectleave: Deleteleave!
    var menu: SideMenuNavigationController?
    
    let serialNo = UserDefaultsManager.shared.getserielNo() ?? ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        menu = SideMenuNavigationController(rootViewController: MenuViewController())
               menu?.leftSide = false
               
               SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        home.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }
        
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
    }
    

}
    override func viewWillAppear(_ animated: Bool) {
        approveleaveAPI()
    }

    func approveleaveAPI() {
        APIHandler().getAPIValues(type: approveleaveModel.self, apiUrl: ServiceAPI.approveleaveURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.approve = data
                print(self.approve.data ?? "")
                print(self.approve.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.approveleaveTableViewCell.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    func acceptleaveAPI(serialNo : String) {
        let formData : [String:String] = ["sno":serialNo]
        APIHandler().postAPIValues(type: acceptleave.self, apiUrl: "\(ServiceAPI.acceptleaveURL)sno=\(serialNo)", method: "POST", formData: formData) { Result in
            switch Result{
            case .success(let data):
                self.acptleave = data
                print(self.acptleave.success )

                DispatchQueue.main.async {
                    self.approveleaveAPI()
                    self.approveleaveTableViewCell.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
        
    }
    func deleteleaveAPI(serialNo : String) {
        let formData : [String:String] = ["sno":serialNo]
        APIHandler().postAPIValues(type: Deleteleave.self, apiUrl: "\(ServiceAPI.deleteleaveURL)sno=\(serialNo)", method: "POST", formData: formData) { Result in
            switch Result{
            case .success(let data):
                self.rejectleave = data
                print(self.rejectleave.success )

                DispatchQueue.main.async {
                    self.approveleaveAPI()
                    self.approveleaveTableViewCell.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
        
    }
}

extension acceptleaveViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.approve?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "approveleaveTableViewCell", for: indexPath) as! approveleaveTableViewCell
        cell.acceptBtn.addAction(for: .tap) {
            
            AlertManager.showCustomAlert(title: "ACCEPT", message: "Do You want to accept this request", viewController: self, okButtonTitle: "ACCEPT", cancelButtonTitle: "Cancel", okHandler:{
                let serialNo = self.approve.data?[indexPath.row].sno ?? ""
                self.acceptleaveAPI(serialNo: serialNo)
            }, cancelHandler: nil)
                                            
        }
        cell.rejectBtn.addAction(for: .tap) {
            
            AlertManager.showCustomAlert(title: "REJECT", message: "Do You Want Reject The Request", viewController: self, okButtonTitle: "REJECT", cancelButtonTitle: "Cancel", okHandler: {
                let serialNo = self.approve.data?[indexPath.row].sno ?? ""
                self.deleteleaveAPI(serialNo: serialNo)
            }, cancelHandler: nil)
            
           

        }
        cell.viewMore.addAction(for: .tap) {
            let nextVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "leaveViewController") as! leaveViewController
            if let approves = self.approve?.data?[indexPath.row]{
                nextVc.bioIdStr = "\(approves.bioid ?? "")"
                nextVc.phoneStr = "\(approves.phonenumber ?? "")"
                nextVc.typeStr = "\(approves.leavetype ?? "")"
                nextVc.titleStr = "\(approves.title ?? "")"
                nextVc.reasonStr = "\(approves.reason ?? "")"
                nextVc.sdateStr = "\(approves.startdate ?? "")"
                nextVc.edateStr = "\(approves.enddate ?? "")"
                
            }
            
            
            self.navigationController?.pushViewController(nextVc, animated: true)
        }

        
        if let approves = self.approve?.data?[indexPath.row] {
            cell.bioid.text = "\(approves.bioid ?? "")"
            cell.leavetitle.text = "\(approves.title ?? "")"
            cell.date.text = "\(approves.startdate ?? "")"
            cell.phone.text = "\(approves.phonenumber ?? "")"
            cell.name.text = "\(approves.leavetype ?? "")"
        
            
            
        } else {
            cell.bioid.text = "Nil"
            cell.leavetitle.text = "Nil"
            cell.date.text = "Nil"
            cell.phone.text = "Nil"
            cell.name.text = "Nil"

        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
}

