//
//  salaryViewController.swift
//  hrApplication
//
//  Created by SAIL on 03/10/23.
//

import UIKit
import SideMenu

class salaryViewController: UIViewController {

    @IBOutlet weak var home: UIImageView!
    @IBOutlet weak var slable: UILabel!
    
    var menu: SideMenuNavigationController?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        menu = SideMenuNavigationController(rootViewController: MenuListViewController())
        menu?.leftSide = false
        
        SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        home.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }
    }
    @IBAction func addsalary(_ sender: Any) {
        let addVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "addsalaryViewController") as! addsalaryViewController
        self.navigationController?.pushViewController(addVC, animated: true)
    }
    @IBAction func viewsalary(_ sender: Any) {
        let viewVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "viewsalaryViewController") as! viewsalaryViewController
        self.navigationController?.pushViewController(viewVC, animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
