//
//  Constant.swift
//  WeatherApp
//
//  Created by MAC-Air on 08/09/23.
//

import Foundation
import UIKit



struct ServiceAPI {
    static let baseURL = "http://192.168.76.171/hrapp1/"
    static let loginUrl = baseURL + "login.php?" // bioid=192011213&password=123
    static let viewProfileUrl = baseURL + "viewprofile.php"
    static let viewSalaryUrl = baseURL + "viewsalary.php"
    static let viewDeptUrl = baseURL + "managedept.php?"
    static let viewHolidayURL = baseURL + "holiday.php?"
    static let addprofileURL = "http://192.168.76.171/hrapp/Apis/addprofile.php?"
    static let adddeptURL = baseURL + "adddept.php?"
    static let addsalaryURL = baseURL + "addsalary.php?"
    static let applyleaveURL = baseURL + "applyleave.php?"
    static let applypermissionURL = baseURL + "applypermission.php?"
    static let approveleaveURL = baseURL + "approveleave.php?"
    static let approvepermissionURL = baseURL + "approvepermission.php?"
    static let profileURL = baseURL + "uprofile.php?" // bioid=\(userId)"
    static let salaryURL = baseURL + "usalary.php?" // bioid=\(userId)"
    static let leavehistoryURL = baseURL + "leavehistory.php?" // bioid=\(userId)"
    static let deleteprofileURL = baseURL + "deleteprofile.php?" // bioid=\(userId)"
    static let deletedeptURL = baseURL + "deletedept.php?" // sno=\(serialNo)"
    static let acceptleaveURL = baseURL + "acceptleave.php?" // sno=\(serialNo)"
    static let acceptpermissionURL = baseURL + "acceptpermission.php?" // sno=\(serialNo)"
    static let deleteleaveURL = baseURL + "deleteleave.php?" // sno=\(serialNo)"
    static let deletepermissionURL = baseURL + "deletepermission.php??" // sno=\(serialNo)"
    static let attendanceURL = baseURL + "attendance.php?" // bioid=\(userId)
    static let attendancecountURL = baseURL + "attendancecount.php?" // bioid=\(userId)
    static let leavebalanceURL = baseURL + "leavebalance.php?" // bioid=\(userId)

}

   
