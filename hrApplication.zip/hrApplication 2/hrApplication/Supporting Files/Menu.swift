//
//  Menu.swift
//  hrApplication
//
//  Created by Haris Madhavan on 06/10/23.
//

import Foundation
import UIKit
import SideMenu

class MenuListViewController: UITableViewController{
    
    var items = ["Home", "Main", "Workflow", "Setup", "Log Out"]
    
    // home, profile, salary, leave, logout
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = items[indexPath.row]
        cell.textLabel?.textColor = .black
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0{
            let homeVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "adminhomeViewController") as! adminhomeViewController
            self.navigationController?.pushViewController(homeVC, animated: true)
            
        } else if indexPath.row == 1{
          let mainbtVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "mainViewController") as! mainViewController
           self.navigationController?.pushViewController(mainbtVC, animated: true)
            
        }else if indexPath.row == 2{
            let workVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "workflowViewController") as! workflowViewController
            self.navigationController?.pushViewController(workVC, animated: true)
            
        }else if indexPath.row == 3{
            let setupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "setupViewController") as! setupViewController
            self.navigationController?.pushViewController(setupVC, animated: true)
            
        }else if indexPath.row == 4{
            let setupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "loginViewController") as! loginViewController
            self.navigationController?.pushViewController(setupVC, animated: true)
                    
                }
            }
            
        }
    
