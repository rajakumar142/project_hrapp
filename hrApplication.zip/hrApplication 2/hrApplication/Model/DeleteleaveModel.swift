//
//  DeleteleaveModel.swift
//  hrApplication
//
//  Created by SAIL on 25/10/23.
//

import Foundation

struct Deleteleave: Codable{
    let success: Bool
    let message: String
}
