//
//  LeaveBalanceModel.swift
//  hrApplication
//
//  Created by SAIL on 14/11/23.
//

import Foundation

struct LeaveBalanceModel: Codable{
    let data: [Balance]
}
struct Balance: Codable {
    let compOff, sickLeave, casualLeave, maternityLeave: Int
    let vacationLeave, specialCasualLeave, total: Int

    enum CodingKeys: String, CodingKey {
        case compOff = "comp_off"
        case sickLeave = "sick_leave"
        case casualLeave = "casual_leave"
        case maternityLeave = "maternity_leave"
        case vacationLeave = "vacation_leave"
        case specialCasualLeave = "Special_Casual_leave"
        case total
    }
}
