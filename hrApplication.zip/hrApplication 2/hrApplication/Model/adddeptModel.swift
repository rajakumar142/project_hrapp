//
//  adddeptModel.swift
//  hrApplication
//
//  Created by SAIL on 14/10/23.
//

import Foundation

struct adddeptModel: Codable {
    var success: Bool?
    var message: String?
}
