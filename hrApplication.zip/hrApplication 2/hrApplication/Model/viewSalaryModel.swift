//
//  viewSalaryModel.swift
//  hrApplication
//
//  Created by SAIL L1 on 11/10/23.
//

import Foundation

// MARK: - Welcome
struct salaryModel: Codable {
    var salaries: [Salary]?
}

// MARK: - Salary
struct Salary: Codable {
    var bioid, date, basicsalary, allowance: String?
    var total: String?
}
