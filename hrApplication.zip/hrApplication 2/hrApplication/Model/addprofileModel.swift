//
//  addprofileModel.swift
//  hrApplication
//
//  Created by SAIL on 14/10/23.
//

import Foundation

struct addprofileModel: Codable {
    var message: String
}
