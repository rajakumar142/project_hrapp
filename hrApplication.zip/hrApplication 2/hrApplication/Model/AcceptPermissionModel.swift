//
//  AcceptPermissionModel.swift
//  hrApplication
//
//  Created by SAIL on 25/10/23.
//

import Foundation

struct acceptpermission: Codable{
    let success: Bool
    let message: String
}
