//
//  applypermission.swift
//  hrApplication
//
//  Created by SAIL on 17/10/23.
//

import Foundation

struct applypermissionModel: Codable {
    var success: Bool?
    var message: String?
}
