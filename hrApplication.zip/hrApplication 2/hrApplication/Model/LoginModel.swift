//
//  LoginModel.swift
//  hrApplication
//
//  Created by SAIL on 13/10/23.
//

import Foundation

// MARK: - Welcome
struct LoginModel: Codable {
    var success: Bool?
    var message: String?
    var data: [LoginmodelData]?
}

// MARK: - Datum
struct LoginmodelData: Codable {
    var usertype, bioid, password: String?
}
