//
//  AttendanceModel.swift
//  hrApplication
//
//  Created by SAIL on 26/10/23.
//

import Foundation

struct AttendanceModel: Codable{
    var data: [attendance]?
}

struct attendance: Codable{
    var presentPercentage, absentPercentage, latePercentage: Double?
    
    enum CodingKeys: String, CodingKey {
        case presentPercentage = "present_percentage"
        case absentPercentage = "absent_percentage"
        case latePercentage = "late_percentage"
    }
}
