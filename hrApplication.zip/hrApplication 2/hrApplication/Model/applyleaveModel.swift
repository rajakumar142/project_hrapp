//
//  applyleaveModel.swift
//  hrApplication
//
//  Created by SAIL on 17/10/23.
//

import Foundation

struct applyleaveModel: Codable {
    var success: Bool?
    var message: String?
}
