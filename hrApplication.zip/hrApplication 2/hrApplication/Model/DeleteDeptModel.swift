//
//  DeleteDeptModel.swift
//  hrApplication
//
//  Created by SAIL on 24/10/23.
//

import Foundation

struct deletedept: Codable{
    let success: String
}
