//
//  manageDeptModel.swift
//  hrApplication
//
//  Created by SAIL on 12/10/23.
//

import Foundation

struct managedept: Codable {
    var departments: [Department]?
}

// MARK: - Department
struct Department: Codable {
    var sno, department, deleteURL: String?

    enum CodingKeys: String, CodingKey {
        case sno, department
        case deleteURL = "delete_url"
    }
}
