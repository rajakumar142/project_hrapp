//
//  userprofileModel.swift
//  hrApplication
//
//  Created by SAIL on 17/10/23.
//

import Foundation

struct userprofileModel: Codable {
    var data: [uprofile]?
}

// MARK: - Datum
struct uprofile: Codable {
    var name, email, dob, phonenumber: String?
    var jobtype, designation, department, experience: String?
    var shift, image: String?

    enum CodingKeys: String, CodingKey {
        case name, email
        case dob = "DOB"
        case phonenumber, jobtype, designation, department, experience, shift, image
    }
}
