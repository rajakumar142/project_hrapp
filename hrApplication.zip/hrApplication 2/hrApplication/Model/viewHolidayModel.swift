//
//  viewHolidayModel.swift
//  hrApplication
//
//  Created by SAIL on 12/10/23.
//

import Foundation

struct HolidayModel: Codable {
    let success: Bool
    let message: String
    let data: [HolidayData]
}

struct HolidayData: Codable {
    let sno, date, day, holidayName: String

    enum CodingKeys: String, CodingKey {
        case sno = "Sno"
        case date = "Date"
        case day = "Day"
        case holidayName = "HolidayName"
    }
}
