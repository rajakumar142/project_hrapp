//
//  AttendanceCountModel.swift
//  hrApplication
//
//  Created by SAIL on 26/10/23.
//

import Foundation

struct AttendanceCountModel: Codable{
    var data: [attendancecount]?
}
struct attendancecount: Codable{
    var presentCount, absentCount, lateCount: String?
    
    enum CodingKeys: String, CodingKey {
        case presentCount = "present_count"
        case absentCount = "absent_count"
        case lateCount = "late_count"
    }
}
