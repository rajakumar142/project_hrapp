//
//  addsalaryModel.swift
//  hrApplication
//
//  Created by SAIL on 14/10/23.
//

import Foundation

struct addsalaryModel: Codable {
    var success: Bool?
    var message: String?
}
