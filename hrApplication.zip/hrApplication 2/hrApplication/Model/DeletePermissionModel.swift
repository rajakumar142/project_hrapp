//
//  DeletePermissionModel.swift
//  hrApplication
//
//  Created by SAIL on 25/10/23.
//

import Foundation

struct Deletepermission: Codable{
    let success: Bool
    let message: String
}
