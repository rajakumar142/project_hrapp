//
//  DeleteProfleModel.swift
//  hrApplication
//
//  Created by SAIL on 24/10/23.
//

import Foundation

struct deleteprofile: Codable{
    let success: Bool
    let message: String
}
