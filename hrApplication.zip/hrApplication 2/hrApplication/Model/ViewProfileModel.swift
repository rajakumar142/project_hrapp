//
//  ViewProfileModel.swift
//  hrApplication
//
//  Created by SAIL L1 on 11/10/23.
//

import Foundation

struct ViewProfile: Codable {
    var data: [Datum]?
}

// MARK: - Datum
struct Datum: Codable {
    var bioid, name, email, dob: String?
    var phonenumber, jobtype, designation, department: String?
    var experience, shift, image: String?

    enum CodingKeys: String, CodingKey {
        case bioid, name, email
        case dob = "DOB"
        case phonenumber, jobtype, designation, department, experience, shift, image
    }
}
