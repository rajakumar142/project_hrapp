//
//  approvepermissionModel.swift
//  hrApplication
//
//  Created by SAIL on 25/10/23.
//

import Foundation

struct approvepermissionModel: Codable {
    var data: [approvepermissions]?
}

// MARK: - Datum
struct approvepermissions: Codable {
    var sno, bioid, title, date : String?
    var phonenumber, starttime, endtime, reason: String?
}

