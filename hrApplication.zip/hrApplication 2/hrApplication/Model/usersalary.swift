//
//  usersalary.swift
//  hrApplication
//
//  Created by SAIL on 18/10/23.
//

import Foundation

struct usersalaryModel: Codable {
    var data: [usalary]?
}

// MARK: - Datum
struct usalary: Codable {
    var date, basicsalary, allowance, total: String?
}
