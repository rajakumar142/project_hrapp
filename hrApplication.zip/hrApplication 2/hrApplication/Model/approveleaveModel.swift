//
//  approveleaveModel.swift
//  hrApplication
//
//  Created by SAIL on 18/10/23.
//

import Foundation

struct approveleaveModel: Codable {
    var data: [approveleaves]?
}

// MARK: - Datum
struct approveleaves: Codable {
    var sno, bioid, title, startdate, enddate: String?
    var phonenumber, leavetype, reason: String?
}

