//
//  reviewVc.swift
//  hrApplication
//
//  Created by SAIL on 26/09/23.
//

import UIKit
import SideMenu

class reviewVc: UIViewController {

    @IBOutlet weak var home: UIImageView!
    @IBOutlet weak var head: UILabel!
    
    var menu: SideMenuNavigationController?
    override func viewDidLoad() {
        super.viewDidLoad()

        menu = SideMenuNavigationController(rootViewController: MenuViewController())
               menu?.leftSide = false
               
               SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        home.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }
    }
    
    @IBAction func approveleave(_ sender: Any) {
        let leaveVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "acceptleaveViewController") as! acceptleaveViewController
        self.navigationController?.pushViewController(leaveVC, animated: true)
    }
    @IBAction func approvepermission(_ sender: Any) {
        let permissionVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "acceptPermissionViewController") as! acceptPermissionViewController
        self.navigationController?.pushViewController(permissionVC, animated: true)
    }
    
   

}
