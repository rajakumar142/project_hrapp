//
//  viewprofileViewController.swift
//  hrApplication
//
//  Created by SAIL on 03/10/23.
//

import UIKit
import SideMenu

class viewprofileViewController: UIViewController {

    @IBOutlet weak var home: UIImageView!
    @IBOutlet weak var slable: UILabel!
    @IBOutlet weak var back: UIImageView!
    
    @IBOutlet weak var viewProfileTableView: UITableView! {
        didSet {
            viewProfileTableView.delegate = self
            viewProfileTableView.dataSource = self
        }
    }
    
    var profile: ViewProfile!
    var menu: SideMenuNavigationController?
    	
    override func viewDidLoad() {
        super.viewDidLoad()
        
        menu = SideMenuNavigationController(rootViewController: MenuListViewController())
        menu?.leftSide = false
        
        SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        home.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }
        
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getProfileAPI()
    }

    func getProfileAPI() {
        APIHandler().getAPIValues(type: ViewProfile.self, apiUrl: ServiceAPI.viewProfileUrl, method: "GET") { result in
            switch result {
            case .success(let data):
                self.profile = data
                print(self.profile.data ?? "")
                print(self.profile.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.viewProfileTableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}

extension viewprofileViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.profile?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "viewprofileTableViewCell", for: indexPath) as! viewprofileTableViewCell
        
        cell.viewbt.addAction(for: .tap) {
            let nextVc = UIStoryboard(name: "Main", bundle: nil)
                .instantiateViewController(withIdentifier: "viewprofileinfoViewController") as! viewprofileinfoViewController
            self.navigationController?.pushViewController(nextVc, animated: true)
            if let profiles = self.profile?.data?[indexPath.row]{
                nextVc.bioidStr = "\(profiles.bioid ?? "")"
                nextVc.nameStr = "\(profiles.name ?? "")"
                nextVc.emailStr = "\(profiles.email ?? "")"
                nextVc.dobStr = "\(profiles.dob ?? "")"
                nextVc.phoneStr = "\(profiles.phonenumber ?? "")"
                nextVc.jobtypeStr = "\(profiles.jobtype ?? "")"
                nextVc.designationStr = "\(profiles.designation ?? "")"
                nextVc.departmentStr = "\(profiles.department ?? "")"
                nextVc.experienceStr = "\(profiles.experience ?? "")"
                nextVc.imageurlStr = "\(profiles.image ?? "")"
            }
        }
        
        if let profiles = self.profile?.data?[indexPath.row] {
            cell.bioid.text = "\(profiles.bioid ?? "")"
            cell.name.text = "\(profiles.name ?? "")"
          //  let imageString
            
//
            let imageString = String(profiles.image ?? "http://192.168.76.171/hrapp/uploads/profile655b9adf1945ddefault.png")
            if let imageURL = URL(string: imageString) {

                        DispatchQueue.global().async {
                            if let imageData = try? Data(contentsOf: imageURL) {

                                if let image = UIImage(data: imageData) {
                                    DispatchQueue.main.async {
                                        cell.pimage.image = image

                                    }
                                }
                            }
                        }
                    }
                
          
            
            
        } else {
            cell.bioid.text = "Nil"
            cell.name.text = "Nil"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
}
