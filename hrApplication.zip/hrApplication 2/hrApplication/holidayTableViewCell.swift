//
//  holidayTableViewCell.swift
//  hrApplication
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class holidayTableViewCell: UITableViewCell {

    @IBOutlet weak var Sno: UILabel!
    @IBOutlet weak var lable1: UILabel!
    @IBOutlet weak var lable2: UILabel!
    @IBOutlet weak var HolidayName: UILabel!
    @IBOutlet weak var Date: UILabel!
    @IBOutlet weak var Day: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
