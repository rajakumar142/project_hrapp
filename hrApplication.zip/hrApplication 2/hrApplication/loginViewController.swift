//
//  loginViewController.swift
//  hrApplication
//
//  Created by SAIL on 20/09/23.
//

import UIKit

class loginViewController: UIViewController {

    @IBOutlet weak var bioid: UITextField!
    @IBOutlet weak var password: UITextField!
    
    let defaults = UserDefaults.standard
    
    var apiURL = String()
    var login: LoginModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }
    override func viewDidDisappear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true
    }
    
    @IBAction func bioid(_ sender: Any) {
       
    }

    @IBAction func password(_ sender: Any) {
    }
    
    @IBAction func bt1(_ sender: Any) {
        
        
        apiURL = "http://192.168.76.171/hrapp/Apis/login.php?bioid=\(bioid.text ?? "")&password=\(password.text ?? "")"
        
        if bioid.text == "" && password.text == "" {
            let alert = UIAlertController(title: "Alert", message: "Textfield is Empty", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            present(alert, animated: true)
        } else {
            getLoginAPI()
        }
    }
    
    func getLoginAPI() {
        APIHandler().getAPIValues(type: LoginModel.self, apiUrl: apiURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.login = data
                print(self.login.data ?? "")
                DispatchQueue.main.async {
                    UserDefaultsManager.shared.saveUserId(self.bioid.text ?? "")
                    if self.bioid.text != self.login.data?.first?.bioid && self.password.text != self.login.data?.first?.password {
                        let alert = UIAlertController(title: "Alert", message: "Incorrect ID or Password", preferredStyle: UIAlertController.Style.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                        self.present(alert, animated: true)
                    } else {
                        if self.login.data?.first?.usertype == "admin" {
                            UserDefaultsManager.shared.saveUserId(self.bioid.text ?? "")
                            let storyboard = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "adminhomeViewController") as! adminhomeViewController
                            self.navigationController?.pushViewController(storyboard, animated: true)
                        } else {
                            UserDefaultsManager.shared.saveUserType(self.login.data?.first?.usertype ?? "")
                            UserDefaultsManager.shared.saveUserId(self.bioid.text ?? "")
                            let storyboard = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "InitialTabBar") as! InitialTabBar
                            self.navigationController?.pushViewController(storyboard, animated: true)
                        }
                    }
                }
            case .failure(let error):
                print(error)
            }
        }
    }

}
