//
//  addsalarylistViewController.swift
//  hrApplication
//
//  Created by SAIL on 15/11/23.
//
import UIKit
import SideMenu

class addsalarylistViewController: UIViewController {
    @IBOutlet weak var home: UIImageView!
    @IBOutlet weak var back: UIImageView!
    
    @IBOutlet weak var addsalarytablelist: UITableView!{
        didSet {
                   addsalarytablelist.delegate = self
                   addsalarytablelist.dataSource = self
               }
           }
           
           var profile: ViewProfile!
           var menu: SideMenuNavigationController?
           
           override func viewDidLoad() {
               super.viewDidLoad()
               
               menu = SideMenuNavigationController(rootViewController: MenuListViewController())
               menu?.leftSide = false
               
               SideMenuManager.default.rightMenuNavigationController = menu
               SideMenuManager.default.addPanGestureToPresent(toView: self.view)
               
               home.addAction(for: .tap) {
                   self.present(self.menu!, animated: true, completion: nil)
               }
               
               back.addAction(for: .tap) {
                   self.navigationController?.popViewController(animated: true)
               }
           }
           
           override func viewWillAppear(_ animated: Bool) {
               getProfileAPI()
           }

           func getProfileAPI() {
               APIHandler().getAPIValues(type: ViewProfile.self, apiUrl: ServiceAPI.viewProfileUrl, method: "GET") { result in
                   switch result {
                   case .success(let data):
                       self.profile = data
                       print(self.profile.data ?? "")
                       print(self.profile.data?.count ?? 0)
                       DispatchQueue.main.async {
                           self.addsalarytablelist.reloadData()
                       }
                   case .failure(let error):
                       print(error)
                   }
               }
           }
       }

       extension addsalarylistViewController: UITableViewDataSource {
           func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
               return self.profile?.data?.count ?? 1
           }

           func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
               let cell = tableView.dequeueReusableCell(withIdentifier: "addsalarylistTableViewCell", for: indexPath) as! addsalarylistTableViewCell
               
               if let profiles = self.profile?.data?[indexPath.row] {
                   cell.bioid.text = "\(profiles.bioid ?? "")"
                   cell.name.text = "\(profiles.name ?? "")"
               } else {
                   cell.bioid.text = "Nil"
                   cell.name.text = "Nil"
               }
               
               return cell
           }
           
           func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
               return 120
           }
       }

       extension addsalarylistViewController: UITableViewDelegate {
           // If you have UITableViewDelegate methods, you can put them here
       }
