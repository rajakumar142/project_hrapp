//
//  adddeptViewController.swift
//  hrApplication
//
//  Created by SAIL on 27/09/23.
//

import UIKit
import SideMenu

class adddeptViewController: UIViewController {
    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var home: UIImageView!
    @IBOutlet weak var slable: UILabel!
    @IBOutlet weak var dept: BorderedTextField!
    
    var menu: SideMenuNavigationController?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        menu = SideMenuNavigationController(rootViewController: MenuListViewController())
        menu?.leftSide = false
        
        SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        home.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }
        
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }

        // Do any additional setup after loading the view.
    }
    

    @IBAction func adddeptbt(_ sender: Any) {
        addDeptAPI()
//        let addVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "adminhomeViewController") as! adminhomeViewController
//        self.navigationController?.pushViewController(addVC, animated: true)
        
    }
    
    func addDeptAPI() {
        let formData: [String: String] = [

            "department": dept.text ?? ""
        ]
        APIHandler().postAPIValues(type: adddeptModel.self, apiUrl: ServiceAPI.adddeptURL, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Success: \(response.success)")
                print("Message: \(response.message ?? "")")
                DispatchQueue.main.async {
                    for controller in self.navigationController!.viewControllers as Array {
                        if controller.isKind(of: adminhomeViewController.self) {
                            self.navigationController!.popToViewController(controller, animated: true)
                            break
                        }
                    }
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }
    }
    
}

   
