//
//  editprofileTableViewCell.swift
//  hrApplication
//
//  Created by SAIL on 18/12/23.
//

import UIKit

class editprofileTableViewCell: UITableViewCell {

    @IBOutlet weak var editbt: UIButton!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var bioid: UILabel!
    @IBOutlet weak var pimage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
