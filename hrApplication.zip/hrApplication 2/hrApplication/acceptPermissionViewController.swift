//
//  acceptPermissionViewController.swift
//  hrApplication
//
//  Created by SAIL on 26/09/23.
//

import UIKit
import SideMenu

class acceptPermissionViewController: UIViewController {

    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var head: UILabel!
    @IBOutlet weak var home: UIImageView!
    @IBOutlet weak var acceptPermisssionTableView: UITableView!{
        didSet {
            acceptPermisssionTableView.delegate = self
            acceptPermisssionTableView.dataSource = self
        }
    }
    var approve: approvepermissionModel!
    var acptpermission: acceptpermission!
    var rejectpermission: Deletepermission!
    var menu: SideMenuNavigationController?
    
    let serialNo = UserDefaultsManager.shared.getserielNo() ?? ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        menu = SideMenuNavigationController(rootViewController: MenuViewController())
               menu?.leftSide = false
               
               SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        home.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }
        
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
    }
       
    }
    
    override func viewWillAppear(_ animated: Bool) {
        approvepermissionAPI()
    }

    func approvepermissionAPI() {
        APIHandler().getAPIValues(type: approvepermissionModel.self, apiUrl: ServiceAPI.approvepermissionURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.approve = data
                print(self.approve.data ?? "")
                print(self.approve.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.acceptPermisssionTableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    func acceptpermissionAPI(serialNo : String) {
        let formData : [String:String] = ["sno":serialNo]
        APIHandler().postAPIValues(type: acceptpermission.self, apiUrl: "\(ServiceAPI.acceptpermissionURL)sno=\(serialNo)", method: "POST", formData: formData) { Result in
            switch Result{
            case .success(let data):
                self.acptpermission = data
                print(self.acptpermission.success )

                DispatchQueue.main.async {
                    self.approvepermissionAPI()
                    self.acceptPermisssionTableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
        
    }
    func deletepermissionAPI(serialNo : String) {
        let formData : [String:String] = ["sno":serialNo]
        APIHandler().postAPIValues(type: Deletepermission.self, apiUrl: "\(ServiceAPI.deletepermissionURL)sno=\(serialNo)", method: "POST", formData: formData) { Result in
            switch Result{
            case .success(let data):
                self.rejectpermission = data
                print(self.rejectpermission.success )

                DispatchQueue.main.async {
                    self.approvepermissionAPI()
                    self.acceptPermisssionTableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
        
    }
}

extension acceptPermissionViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.approve?.data?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "acceptPermissionTableViewCell", for: indexPath) as! acceptPermissionTableViewCell
        
        cell.accetpbt.addAction(for: .tap) {
            
            AlertManager.showCustomAlert(title: "ACCEPT", message: "Do You want to accept this request", viewController: self, okButtonTitle: "ACCEPT", cancelButtonTitle: "Cancel", okHandler: {
                let serialNo = self.approve.data?[indexPath.row].sno ?? ""
                self.acceptpermissionAPI(serialNo: serialNo)
            }, cancelHandler: nil)
            
            
        }
        
        cell.deletebt.addAction(for: .tap) {
            
            AlertManager.showCustomAlert(title: "REJECT", message: "Do You Want Reject The Request", viewController: self, okButtonTitle: "REJECT", cancelButtonTitle: "Cancel", okHandler: {
                let serialNo = self.approve.data?[indexPath.row].sno ?? ""
                self.deletepermissionAPI(serialNo: serialNo)
            }, cancelHandler: nil)
            

        }
        
        cell.viewMore.addAction(for: .tap) {
            let nextVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "permissionViewController") as! permissionViewController
            if let approves = self.approve?.data?[indexPath.row]{
                nextVc.bioIdStr = "\(approves.bioid ?? "")"
                nextVc.phoneStr = "\(approves.phonenumber ?? "")"
                nextVc.dateStr = "\(approves.date ?? "")"
                nextVc.titleStr = "\(approves.title ?? "")"
                nextVc.reasonStr = "\(approves.reason ?? "")"
                nextVc.stimeStr = "\(approves.starttime ?? "")"
                nextVc.etimeStr = "\(approves.endtime ?? "")"
                
            }
            
            
            self.navigationController?.pushViewController(nextVc, animated: true)
        }
        
        if let approves = self.approve?.data?[indexPath.row] {
            cell.bioid.text = "\(approves.bioid ?? "")"
            cell.gtitle.text = "\(approves.title ?? "")"
            cell.gdate.text = "\(approves.date ?? "")"
            cell.phone.text = "\(approves.phonenumber ?? "")"

        } else {
            cell.bioid.text = "Nil"
            cell.gtitle.text = "Nil"
            cell.gdate.text = "Nil"
            cell.phone.text = "Nil"

        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
}

