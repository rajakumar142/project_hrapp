//
//  tab3apleaveViewController.swift
//  hrApplication
//
//  Created by SAIL on 05/10/23.
//

import UIKit

class tab3apleaveViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func leave(_ sender: Any) {
        let leaveVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "applyleaveViewController") as! applyleaveViewController
        self.navigationController?.pushViewController(leaveVC, animated: true)
    }
    @IBAction func permission(_ sender: Any) {
        let permissionVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "applypermissionViewController") as! applypermissionViewController
        self.navigationController?.pushViewController(permissionVC, animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
