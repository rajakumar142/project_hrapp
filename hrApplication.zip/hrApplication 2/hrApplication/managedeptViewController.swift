//
//  managedeptViewController.swift
//  hrApplication
//
//  Created by SAIL on 27/09/23.
//

import UIKit
import SideMenu

class managedeptViewController: UIViewController {

    @IBOutlet weak var slable: UILabel!
    @IBOutlet weak var managedepttable: UITableView!{
        didSet {
            managedepttable.delegate = self
            managedepttable.dataSource = self
        }
    }
    
    var dept: managedept!
    var deldept: deletedept!
    var menu: SideMenuNavigationController?
    
    @IBOutlet weak var home: UIImageView!
    @IBOutlet weak var back: UIImageView!
    
    let serialNo = UserDefaultsManager.shared.getserielNo() ?? ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        menu = SideMenuNavigationController(rootViewController: MenuListViewController())
        menu?.leftSide = false
        
        SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        home.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }

        
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        getDeptAPI()
    }
    
    func getDeptAPI() {
        APIHandler().getAPIValues(type: managedept.self, apiUrl: ServiceAPI.viewDeptUrl, method: "GET") { result in
            switch result {
            case .success(let data):
                self.dept = data
                print(self.dept.departments ?? "")
                print(self.dept.departments?.count ?? 0)
                DispatchQueue.main.async {
                    self.managedepttable.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    func DeleteDeptAPI(serialNo : String) {
        let formData : [String:String] = ["sno":serialNo]
        APIHandler().postAPIValues(type: deletedept.self, apiUrl: "\(ServiceAPI.deletedeptURL)sno=\(serialNo)", method: "POST", formData: formData) { Result in
            switch Result{
            case .success(let data):
                self.deldept = data
                print(self.deldept.success )

                DispatchQueue.main.async {
                    self.getDeptAPI()
                    self.managedepttable.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
        
    }
}

extension managedeptViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.dept?.departments?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "managedeptTableViewCell", for: indexPath) as! managedeptTableViewCell
        cell.deleteBT.addAction(for: .tap) {
            
            AlertManager.showCustomAlert(title: "Delete", message: "Do you want to delete?", viewController: self, okButtonTitle: "DELETE", cancelButtonTitle: "Cancel", okHandler: {
                let serialNo = self.dept.departments?[indexPath.row].sno ?? ""
    //            UserDefaultsManager.shared.saveserielNo(self.dept.departments?[indexPath.row].sno ?? "")
                self.DeleteDeptAPI(serialNo: serialNo)
            }, cancelHandler: nil)

        }
        
        if let departments = self.dept?.departments?[indexPath.row] {
            cell.department.text = "\(departments.department ?? "")"
           
            
            
        } else {
            cell.department.text = "Nil"
           
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
}
