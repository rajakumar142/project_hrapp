//
//  editProfileViewController.swift
//  hrApplication
//
//  Created by SAIL on 18/12/23.
//

import UIKit
import SideMenu

class editProfileViewController: UIViewController {
    
    var profile: userprofileModel!
    var menu: SideMenuNavigationController?
    
    var bioidStr = String()
    var nameStr = String()
    var emailStr = String()
    var dobStr = String()
    var phoneStr = String()
    var jobtypeStr = String()
    var designationStr = String()
    var departmentStr = String()
    var experienceStr = String()
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
