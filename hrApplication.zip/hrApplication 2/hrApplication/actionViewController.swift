//
//  actionViewController.swift
//  hrApplication
//
//  Created by SAIL on 05/10/23.
//

import UIKit
import SideMenu

class actionViewController: UIViewController {
    
    @IBOutlet weak var menu: UIImageView!
    @IBOutlet weak var reviewOt: UIButton!
   
    var Menu: SideMenuNavigationController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Menu = SideMenuNavigationController(rootViewController: MenuViewController())
               Menu?.leftSide = false

               SideMenuManager.default.rightMenuNavigationController = Menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)

        menu.addAction(for: .tap) {
            self.present(self.Menu!, animated: true, completion: nil)
        }

        if UserDefaultsManager.shared.getUserType() == "user" {
            reviewOt.isHidden = true
        }
        
    }
    @IBAction func leavebt(_ sender: Any) {
        let leaveVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "allleaveViewController") as! allleaveViewController
        self.navigationController?.pushViewController(leaveVC, animated: true)
    }
    @IBAction func salarybt(_ sender: Any) {
        let salaryVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "viewsalaryuViewController") as! viewsalaryuViewController
        self.navigationController?.pushViewController(salaryVC, animated: true)
    }
    @IBAction func reviewbt(_ sender: Any) {
        let reviewVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "reviewVc") as! reviewVc
        self.navigationController?.pushViewController(reviewVC, animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
