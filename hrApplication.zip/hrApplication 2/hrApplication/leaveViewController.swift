//
//  leaveViewController.swift
//  hrApplication
//
//  Created by SAIL on 15/11/23.
//

import UIKit
import SideMenu

class leaveViewController: UIViewController {

    @IBOutlet weak var home: UIImageView!
    @IBOutlet weak var phone: UILabel!
    @IBOutlet weak var ltype: UILabel!
    @IBOutlet weak var sdate: UILabel!
    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var reason: UILabel!
    @IBOutlet weak var edate: UILabel!
    @IBOutlet weak var leavetitle: UILabel!
    @IBOutlet weak var bioid: UILabel!
    
    var approve: approveleaveModel!
    var menu: SideMenuNavigationController?
    
    var bioIdStr = String()
    var titleStr = String()
    var typeStr = String()
    var sdateStr = String()
    var edateStr = String()
    var phoneStr = String()
    var reasonStr = String()
    
    
    override func viewDidLoad() {
        
        bioid.text = bioIdStr
        leavetitle.text = titleStr
        ltype.text = typeStr
        sdate.text = sdateStr
        edate.text = edateStr
        phone.text = phoneStr
        reason.text = reasonStr
        
        
        super.viewDidLoad()
        menu = SideMenuNavigationController(rootViewController: MenuViewController())
               menu?.leftSide = false
               
               SideMenuManager.default.rightMenuNavigationController = menu
        SideMenuManager.default.addPanGestureToPresent(toView: self.view)
        
        home.addAction(for: .tap) {
            self.present(self.menu!, animated: true, completion: nil)
        }
        
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
    }
    

    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
